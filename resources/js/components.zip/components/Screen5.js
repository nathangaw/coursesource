// create management account

import {useState} from "@wordpress/element";
import parse from 'html-react-parser';
import csForm from "./Form";

const Screen5 = (props) => {
    //Get some sensible defaults...
    const companyField = document.getElementById('billing_company');

    // Customise  setState so we can work with objects easily...
    const useSetState = (initialState = {}) => {
        const [state, regularSetState] = useState(initialState);
        const setState = newState => {
            regularSetState(prevState => ({
                ...prevState,
                ...newState
            }));
        };
        return [state, setState];
    };

    const [formState, setFormState] = useSetState({
        organisation: (companyField) ? companyField.value : '',
        exists : false,
        allocation: false,
    });

    const [formErrors, setFormErrors] = useSetState({
        organisation: {
            error: false,
            message: '',
            validators: [
                {
                    name: 'notEmpty',
                    message: 'The Organisation name cannot be empty'
                },
                // {
                //     name : 'groupNotExists',
                //     message : 'This Organisation Name already exists. Please choose a different name'
                // }
            ]
        }
    });

    const [continueButtonLabel, setContinueButtonLabel] = useState('Check Group');
    const [creatingAccount, setCreatingAccount] = useState(false);
    const [dataLoading, setDataLoading] = useState(false);
    const [dataLoadingMessage, setDataLoadingMessage] = useState(false);

    const previousScreen = () => {
        props.updateScreenNumber(3)
    }

    const handleOrganisationChange = (event) => {
        setFormState({
            organisation: event.target.value,
            exists: false,
            allocation: false,

        });
        let newFormErrors = {...formErrors};
        newFormErrors.organisation.error = false;
        newFormErrors.organisation.message = null;
        setFormErrors(newFormErrors);
    }

    const handleAllocationChange = (event) => {
        setFormState({
            allocation: !formState.allocation,
        });
        if( formState.allocation ){
            setContinueButtonLabel('Assign to Group');
        }
    }

    /**
     *
     * @param value
     * @param length
     * @returns {boolean}
     */
    const isValidLength = (value, length) => {
        return value.length >= length;
    }

    const formHasErrors = () => {
        setFormErrors(csForm.validateForm(formState, formErrors));
        let formErrorValues = Object.values(formErrors);
        return formErrorValues.some(formError => formError.error === true);
    }

    /**
     *
     * @param groupName
     * @returns {Promise<boolean>}
     */
    const checkGroupExists = async (groupName, formErrors) => {
        let result = false;
        setDataLoading(true);
        setContinueButtonLabel("Checking Group Name..");
        let groupNotExists = await csForm.groupNotExists( groupName );
        if( !groupNotExists ){
            let errorMessage = 'This Organisation Name already exists. Please choose a different name, or tick the box below to assign these Licences to it.'
            let groupManagers = await getGroupManagers( groupName, 'info@sweet-apple.co.uk' );
            console.log('groupManagers', groupManagers);
            if( groupManagers.length === 0){
                errorMessage += "<br><br>";
                errorMessage += "Please note that none of the managers of this Group appear to be from the same email domain as your email address.";
                errorMessage += "<br><br>";
                errorMessage += "You may be assigning your licences to another customer, so please proceed with caution.";
                setContinueButtonLabel("Confirm Group Name");
            }

            let newFormErrors = {...formErrors};
            newFormErrors.organisation.error = true;
            newFormErrors.organisation.message = errorMessage;
            setFormErrors(newFormErrors);
            result = true;
        }
        setDataLoading(false);
        return result;
    }

    const getGroupManagers = async (groupName, userEmail) => {
        let result = await jQuery.ajax({
            url: Coursesource.ajaxurl,
            method: 'post',
            dataType: 'json',
            data: {
                action: 'group_managers',
                nonce: Coursesource.nonce,
                group_name: groupName,
                user_email: userEmail,
            }
        }).done(function (response) {
            console.log('getGroupManagers', response);
            return response;
        });
        if( !result.result ){
            return result.managers;
        }else{
            return [];
        }
    }

    const checkGroup = async (event) => {
        event.preventDefault();
        if (formHasErrors()) {
            return;
        }
        let groupExistsResult = await checkGroupExists(formState.organisation, formErrors);

        if ( groupExistsResult ) {
            setFormState( {
                exists: true,
            } );
        }

        if ( groupExistsResult && !formState.allocation ) {
            return;
        }

        const managerData = {};
        managerData.group = formState.organisation.trim();
        props.updateManagerDetails(managerData);
        props.updateScreenNumber(5);
    }

    return (
        <form className='cs-checkout-groups-screen-4'>
            <h4>Choose a Group</h4>
            <p>
                Choose the name of the Group you want to assign these licences to.
            </p>

            <div className="form-row">
                <input
                    type="text"
                    className="input-text cs-checkout-groups-input"
                    placeholder="Organisation name"
                    value={formState.organisation}
                    required
                    onChange={handleOrganisationChange}
                />
                {formErrors.organisation.error ? (
                    <p className={csForm.formErrorClass('organisation', formErrors)}>
                        {parse(formErrors.organisation.message)}
                    </p>
                ) : null}
            </div>

            {formState.exists ? (
            <div className="form-row">
                <input
                    type="checkbox"
                    id="allocateLearnerToGroup"
                    className="input-text cs-checkout-groups-input"
                    checked={formState.allocation}
                    onChange={handleAllocationChange}
                />
                <label htmlFor="allocateLearnerToGroup">Allocate Learner Enrolments to this Group</label>
            </div>
            ) : null}

            <div className="error-messages">
                {dataLoading ? (
                    <p className="form-error message-error">{dataLoadingMessage}</p>
                ) : null}
            </div>

            <div className="cs-modal-button-actions">
                <button
                    className="btn btn-prev"
                    onClick={previousScreen}
                >
                    Prev
                </button>

                <button
                    className="btn btn-action"
                    onClick={checkGroup}
                >
                    {continueButtonLabel}
                </button>

            </div>

        </form>
    )
}

export default Screen5
